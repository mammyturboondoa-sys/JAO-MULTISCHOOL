// All visible text lives here (English + French). Add a key to BOTH languages when you add text.
export const DICT = { en: {}, fr: {} };
const add = (key, en, fr) => { DICT.en[key] = en; DICT.fr[key] = fr; };

// ---- brand & navigation ----
add('brand.sub', 'School Management System', 'Système de gestion scolaire');
add('brand.by', 'JAO — by Jao', 'JAO — par Jao');
add('nav.main', 'Main navigation', 'Navigation principale');
add('nav.overview', 'Overview', 'Aperçu'); add('nav.students', 'Students', 'Élèves'); add('nav.classes', 'Classes', 'Classes'); add('nav.subjects', 'Subjects', 'Matières');
add('nav.grades', 'Grades', 'Notes'); add('nav.reports', 'Results & Reports', 'Résultats et rapports'); add('nav.shop', 'School Shop', 'Boutique scolaire');
add('nav.products', 'Products & Stock', 'Produits et stock'); add('nav.settings', 'Settings', 'Paramètres'); add('nav.platform', 'Platform', 'Plateforme');
add('nav.open_menu', 'Open menu', 'Ouvrir le menu'); add('nav.notifications', 'Notifications', 'Notifications');
add('notify.none', 'No notifications', 'Aucune notification');
add('notify.low_stock', '{n} product(s) low on stock', '{n} produit(s) en stock bas'); add('notify.out_of_stock', '{n} product(s) out of stock', '{n} produit(s) en rupture de stock');
add('notify.results', '{n} approved report card(s) available', '{n} bulletin(s) approuvé(s) disponible(s)');
add('role.school_admin', 'Administrator', 'Administrateur'); add('role.teacher', 'Teacher', 'Enseignant'); add('role.parent', 'Parent / Guardian', 'Parent / Tuteur');
add('role.student', 'Student', 'Élève'); add('role.platform_owner', 'Super Administrator', 'Super administrateur');

// ---- common ----
add('common.save', 'Save', 'Enregistrer'); add('common.saved', 'Saved', 'Enregistré'); add('common.cancel', 'Cancel', 'Annuler'); add('common.close', 'Close', 'Fermer');
add('common.confirm', 'Confirm', 'Confirmer'); add('common.please_confirm', 'Please confirm', 'Veuillez confirmer'); add('common.back', 'Back', 'Retour'); add('common.next', 'Next', 'Suivant');
add('common.prev', 'Previous', 'Précédent'); add('common.edit', 'Edit', 'Modifier'); add('common.delete', 'Delete', 'Supprimer'); add('common.open', 'Open', 'Ouvrir');
add('common.search', 'Search', 'Rechercher'); add('common.optional', 'optional', 'facultatif'); add('common.loading', 'Loading…', 'Chargement…');
add('common.retry', 'Try again', 'Réessayer'); add('common.error_title', 'Something went wrong', 'Une erreur est survenue'); add('common.active', 'Active', 'Actif'); add('common.inactive', 'Inactive', 'Inactif');
add('common.activate', 'Activate', 'Activer'); add('common.deactivate', 'Deactivate', 'Désactiver'); add('common.date', 'Date', 'Date'); add('common.language', 'Language', 'Langue');
add('common.home', 'Home', 'Accueil'); add('common.copy', 'Copy', 'Copier'); add('common.copied', 'Copied', 'Copié'); add('common.use', 'Use', 'Utiliser'); add('common.leave', 'Leave', 'Quitter');
add('common.page_of', 'Page {p} of {n}', 'Page {p} sur {n}');
add('common.unsaved', 'You have unsaved changes. Leave this page anyway?', 'Vous avez des modifications non enregistrées. Quitter quand même cette page ?');
add('secret.once', 'Write this down now. It is shown only once.', 'Notez-le maintenant. Il n’est affiché qu’une seule fois.');

// ---- welcome / entry / auth ----
add('welcome.tag', 'Seraphim International', 'Seraphim International'); add('welcome.subtitle', 'JAO — School Management System', 'JAO — Système de gestion scolaire');
add('welcome.continue', 'Continue', 'Continuer'); add('welcome.play', 'Play announcement', 'Lire l’annonce'); add('welcome.sound_on', 'Sound off', 'Son désactivé'); add('welcome.sound_off', 'Sound on', 'Son activé');
add('welcome.voice', 'Voice', 'Voix'); add('welcome.voice_default', 'Default', 'Par défaut'); add('welcome.voice_woman', 'Woman', 'Femme'); add('welcome.voice_man', 'Man', 'Homme');
add('welcome.portrait_placeholder', 'Portrait placeholder', 'Portrait provisoire');
add('start.title', 'Welcome to JAO', 'Bienvenue sur JAO'); add('start.text', 'Sign in to your school, or browse the public school shop catalogue.', 'Connectez-vous à votre école, ou consultez le catalogue public de la boutique scolaire.');
add('start.shop', 'School Shop catalogue', 'Catalogue de la boutique'); add('start.register', 'Register your school', 'Inscrire votre école');
add('auth.sign_in', 'Sign in', 'Se connecter'); add('auth.welcome_back', 'Welcome back!', 'Bon retour !'); add('auth.sign_in_text', 'Sign in to your account', 'Connectez-vous à votre compte');
add('auth.email', 'Email', 'E-mail'); add('auth.password', 'Password', 'Mot de passe'); add('auth.logout', 'Sign out', 'Se déconnecter'); add('auth.change_password', 'Change password', 'Changer le mot de passe');
add('auth.current_password', 'Current password', 'Mot de passe actuel'); add('auth.new_password', 'New password', 'Nouveau mot de passe'); add('auth.confirm_password', 'Confirm new password', 'Confirmer le nouveau mot de passe');
add('auth.temp_password', 'Temporary password', 'Mot de passe temporaire'); add('auth.password_changed', 'Password changed', 'Mot de passe modifié');
add('auth.password_rules', 'At least 10 characters, with letters and numbers.', 'Au moins 10 caractères, avec des lettres et des chiffres.');
add('auth.choose_password', 'Choose your password', 'Choisissez votre mot de passe'); add('auth.choose_password_text', 'For your security, replace the temporary password before continuing.', 'Pour votre sécurité, remplacez le mot de passe temporaire avant de continuer.');
add('auth.forgot_help', 'Forgot your password? Ask your school administrator to reset it.', 'Mot de passe oublié ? Demandez à l’administrateur de votre école de le réinitialiser.');
add('register.title', 'Register your school', 'Inscrire votre école'); add('register.text', 'Send a request. The JAO platform owner reviews it, and your school becomes active only after approval.', 'Envoyez une demande. Le propriétaire de la plateforme JAO l’examine et votre école n’est activée qu’après approbation.');
add('register.school_name', 'School name', 'Nom de l’école'); add('register.admin_name', 'Administrator name', 'Nom de l’administrateur'); add('register.message', 'Message', 'Message');
add('register.submit', 'Send request', 'Envoyer la demande'); add('register.sent_title', 'Request sent', 'Demande envoyée'); add('register.sent_text', 'Thank you. You will be contacted once your request has been reviewed.', 'Merci. Vous serez contacté une fois votre demande examinée.');

// ---- overview ----
add('overview.welcome_back', 'Welcome back, {name}!', 'Bienvenue, {name} !'); add('overview.hello', 'Hello, {name}', 'Bonjour, {name}');
add('overview.students', 'Students', 'Élèves'); add('overview.my_students', 'Linked students', 'Élèves liés'); add('overview.teachers', 'Teachers', 'Enseignants'); add('overview.classes', 'Classes', 'Classes'); add('overview.subjects', 'Subjects', 'Matières');
add('overview.quick', 'Quick actions', 'Actions rapides'); add('overview.enter_grades', 'Enter Grades', 'Saisir les notes');
add('overview.shop_summary', 'Shop summary', 'Résumé de la boutique'); add('overview.active_products', 'Active products', 'Produits actifs'); add('overview.low_stock', 'Low stock', 'Stock bas'); add('overview.out_stock', 'Out of stock', 'Rupture de stock');
add('overview.students_per_class', 'Students per class', 'Élèves par classe'); add('overview.no_classes', 'No classes yet.', 'Aucune classe pour le moment.');
add('overview.academic', 'Academic overview — recent assessments', 'Aperçu académique — évaluations récentes'); add('overview.no_assessments', 'No assessments yet.', 'Aucune évaluation pour le moment.');
add('overview.activity', 'Recent activity', 'Activité récente'); add('overview.no_activity', 'No activity yet.', 'Aucune activité pour le moment.');
add('overview.setup_title', 'Let’s set up your school', 'Configurons votre école'); add('overview.setup_text', 'Create the academic year and terms first, then classes, subjects and students.', 'Créez d’abord l’année scolaire et les périodes, puis les classes, les matières et les élèves.');
add('overview.setup_go', 'Open Settings', 'Ouvrir les paramètres');

// ---- students ----
add('students.add', 'Add Student', 'Ajouter un élève'); add('students.edit', 'Edit student', 'Modifier l’élève'); add('students.subtitle', 'Student directory', 'Annuaire des élèves');
add('students.title_parent', 'My children', 'Mes enfants'); add('students.title_student', 'My profile', 'Mon profil');
add('students.search', 'Search by name or student ID', 'Rechercher par nom ou numéro d’élève'); add('students.all_classes', 'All classes', 'Toutes les classes'); add('students.all_years', 'All years', 'Toutes les années'); add('students.all_status', 'All statuses', 'Tous les statuts');
add('students.class', 'Class', 'Classe'); add('students.year', 'Academic year', 'Année scolaire'); add('students.status', 'Status', 'Statut'); add('students.sort', 'Sort by', 'Trier par');
add('students.sort_name', 'Name', 'Nom'); add('students.sort_id', 'Student ID', 'Numéro d’élève'); add('students.sort_enrolled', 'Enrollment date', 'Date d’inscription');
add('students.id', 'ID', 'N°'); add('students.view_profile', 'View Profile', 'Voir le profil'); add('students.count', '{n} student(s)', '{n} élève(s)');
add('students.empty_title', 'No students yet', 'Aucun élève pour le moment'); add('students.empty_text', 'Add your first student to get started.', 'Ajoutez votre premier élève pour commencer.'); add('students.empty_text_other', 'No student records are available to you yet.', 'Aucun dossier d’élève n’est encore disponible pour vous.');
add('students.no_results', 'No matching students', 'Aucun élève correspondant'); add('students.no_results_text', 'Try a different search or clear the filters.', 'Essayez une autre recherche ou effacez les filtres.');
add('students.need_setup', 'Before adding students, create an academic year and at least one class.', 'Avant d’ajouter des élèves, créez une année scolaire et au moins une classe.');
add('students.archive', 'Archive', 'Archiver'); add('students.archived', 'Student archived', 'Élève archivé'); add('students.archive_confirm', 'Archive {name}? The record and its history are kept but hidden from lists.', 'Archiver {name} ? Le dossier et son historique sont conservés mais masqués des listes.');
add('status.active', 'Active', 'Actif'); add('status.transferred', 'Transferred', 'Transféré'); add('status.graduated', 'Graduated', 'Diplômé');
add('gender.female', 'Female', 'Féminin'); add('gender.male', 'Male', 'Masculin'); add('gender.other', 'Other', 'Autre');
add('form.s1', 'Student information', 'Informations sur l’élève'); add('form.s2', 'Academic information', 'Informations scolaires'); add('form.s3', 'Parent / guardian information', 'Informations sur les parents / tuteurs'); add('form.s4', 'Review & save', 'Vérifier et enregistrer');
add('form.photo', 'Photograph', 'Photo'); add('form.photo_hint', 'JPG, PNG or WebP, up to 2 MB.', 'JPG, PNG ou WebP, 2 Mo maximum.'); add('form.remove_photo', 'Remove photo', 'Supprimer la photo');
add('form.student_id', 'Student ID', 'Numéro d’élève'); add('form.auto_id', 'Created automatically', 'Créé automatiquement'); add('form.auto_id_hint', 'Unique and generated by the system.', 'Unique et généré par le système.');
add('form.full_name', 'Full name', 'Nom complet'); add('form.dob', 'Date of birth', 'Date de naissance'); add('form.gender', 'Gender', 'Genre'); add('form.birthplace', 'Place of birth', 'Lieu de naissance');
add('form.address', 'Home address', 'Adresse du domicile'); add('form.enrolled_on', 'Enrollment date', 'Date d’inscription'); add('form.year', 'Academic year', 'Année scolaire'); add('form.class', 'Class', 'Classe');
add('form.choose_class', 'Choose a class', 'Choisissez une classe'); add('form.stream', 'Section / stream', 'Section / filière'); add('form.stream_hint', 'Only if it applies.', 'Seulement si applicable.');
add('form.status', 'Status', 'Statut'); add('form.previous_school', 'Previous school', 'École précédente');
add('form.guardian_n', 'Guardian {n}', 'Tuteur {n}'); add('form.relationship', 'Relationship', 'Lien de parenté'); add('form.relationship_ph', 'Mother, Father, Uncle…', 'Mère, Père, Oncle…'); add('form.phone', 'Telephone', 'Téléphone'); add('form.email', 'Email', 'E-mail');
add('form.primary', 'Primary contact', 'Contact principal'); add('form.emergency', 'Emergency contact', 'Contact d’urgence'); add('form.add_guardian', 'Add another guardian', 'Ajouter un autre tuteur'); add('form.remove_guardian', 'Remove', 'Retirer');
add('form.review_text', 'Check the information below, then save.', 'Vérifiez les informations ci-dessous, puis enregistrez.'); add('form.save', 'Save Student', 'Enregistrer l’élève'); add('form.saved', 'Student saved', 'Élève enregistré');
add('form.fix_errors', 'Please correct the highlighted fields.', 'Veuillez corriger les champs signalés.');
add('profile.profile', 'Profile', 'Profil'); add('profile.academics', 'Academic Records', 'Résultats scolaires'); add('profile.guardians', 'Guardians', 'Tuteurs'); add('profile.history', 'History', 'Historique');
add('hist.registered', 'Registered', 'Inscription'); add('hist.class_changed', 'Class changed', 'Changement de classe'); add('hist.year_changed', 'Academic year changed', 'Changement d’année scolaire'); add('hist.reactivated', 'Reactivated', 'Réactivé');
add('hist.transferred', 'Transferred', 'Transféré'); add('hist.graduated', 'Graduated', 'Diplômé'); add('hist.archived', 'Archived', 'Archivé'); add('hist.photo_updated', 'Photo updated', 'Photo mise à jour'); add('hist.photo_removed', 'Photo removed', 'Photo supprimée');
add('hist.none', 'No history yet.', 'Aucun historique.');
add('guardian.link_account', 'Link parent login', 'Lier un compte parent'); add('guardian.change_account', 'Change parent login', 'Changer le compte parent'); add('guardian.linked', 'Login linked', 'Compte lié');
add('guardian.parent_account', 'Parent account', 'Compte parent'); add('guardian.no_account', 'No account', 'Aucun compte'); add('guardian.link_help', 'The parent will see only the students linked to this guardian record. Create the parent login first in Settings → Users.', 'Le parent ne verra que les élèves liés à cette fiche de tuteur. Créez d’abord le compte parent dans Paramètres → Utilisateurs.');

// ---- academic records ----
add('acad.term', 'Term', 'Période'); add('acad.subject', 'Subject', 'Matière'); add('acad.coef', 'Coef.', 'Coef.'); add('acad.assessments', 'Assessments', 'Évaluations'); add('acad.average', 'Average /{n}', 'Moyenne /{n}');
add('acad.overall', 'Overall average', 'Moyenne générale'); add('acad.passed', 'Passed', 'Admis'); add('acad.not_passed', 'Below pass mark', 'Sous la moyenne de passage'); add('acad.rank', 'Rank', 'Rang');
add('acad.none_title', 'No academic records yet', 'Aucun résultat pour le moment'); add('acad.none_text', 'Records appear here once assessments are graded.', 'Les résultats apparaissent ici une fois les évaluations notées.'); add('acad.none_approved', 'Results appear here after the administrator approves the report card.', 'Les résultats apparaissent ici après l’approbation du bulletin par l’administrateur.');
add('acad.no_grades', 'No grades recorded for this term.', 'Aucune note enregistrée pour cette période.'); add('acad.partial', 'You only see the subjects assigned to you.', 'Vous ne voyez que les matières qui vous sont attribuées.');
add('acad.rule_note', 'Absent, excused or missing assessments are not counted as zero. Pass mark: {pass}.', 'Les évaluations absentes, excusées ou manquantes ne comptent pas comme zéro. Note de passage : {pass}.');
add('gstatus.graded', 'Graded', 'Notée'); add('gstatus.absent', 'Absent', 'Absent'); add('gstatus.excused', 'Excused', 'Excusé'); add('gstatus.missing', 'Not graded', 'Non notée');

// ---- classes & subjects ----
add('classes.add', 'Add Class', 'Ajouter une classe'); add('classes.edit', 'Edit class', 'Modifier la classe'); add('classes.subtitle', 'Class directory', 'Répertoire des classes'); add('classes.search', 'Search classes', 'Rechercher des classes');
add('classes.name', 'Class name', 'Nom de la classe'); add('classes.section', 'Section', 'Section'); add('classes.teacher', 'Class teacher', 'Enseignant'); add('classes.capacity', 'Maximum capacity', 'Capacité maximale');
add('classes.students_n', '{n} student(s)', '{n} élève(s)'); add('classes.empty_title', 'No classes yet', 'Aucune classe'); add('classes.empty_text', 'Create a class for the current academic year.', 'Créez une classe pour l’année scolaire en cours.'); add('classes.empty_text_teacher', 'No classes are assigned to you yet.', 'Aucune classe ne vous est encore attribuée.');
add('classes.need_year', 'Create an academic year first (Settings).', 'Créez d’abord une année scolaire (Paramètres).'); add('classes.assign_subjects', 'Assign subjects', 'Attribuer des matières'); add('classes.assign_help', 'Tick the subjects taught in this class and set the coefficient for this class.', 'Cochez les matières enseignées dans cette classe et définissez le coefficient pour cette classe.');
add('classes.need_subjects', 'Create subjects first.', 'Créez d’abord des matières.'); add('classes.no_subjects', 'No subjects assigned yet.', 'Aucune matière attribuée.'); add('classes.no_students', 'No students in this class.', 'Aucun élève dans cette classe.');
add('classes.deactivate_confirm', 'Deactivate this class? Its students and grades are kept.', 'Désactiver cette classe ? Ses élèves et ses notes sont conservés.');
add('subjects.add', 'Add Subject', 'Ajouter une matière'); add('subjects.edit', 'Edit subject', 'Modifier la matière'); add('subjects.subtitle', 'Subjects, codes and coefficients', 'Matières, codes et coefficients');
add('subjects.name', 'Name', 'Nom'); add('subjects.code', 'Code', 'Code'); add('subjects.code_hint', 'Unique, letters and numbers only.', 'Unique, lettres et chiffres uniquement.'); add('subjects.classes', 'Assigned classes', 'Classes attribuées'); add('subjects.default_coef', 'Default coefficient', 'Coefficient par défaut');
add('subjects.description', 'Description', 'Description'); add('subjects.empty_title', 'No subjects yet', 'Aucune matière'); add('subjects.empty_text', 'Add the subjects your school teaches.', 'Ajoutez les matières enseignées dans votre école.'); add('subjects.empty_text_teacher', 'No subjects are assigned to you yet.', 'Aucune matière ne vous est encore attribuée.');
add('subjects.deactivate_confirm', 'Deactivate this subject? Past results are kept.', 'Désactiver cette matière ? Les résultats passés sont conservés.');

// ---- grades ----
add('grades.subtitle', 'Choose year, term, class and subject', 'Choisissez l’année, la période, la classe et la matière'); add('grades.assessments', 'Assessments', 'Évaluations'); add('grades.new_assessment', 'New Assessment', 'Nouvelle évaluation');
add('grades.type', 'Type', 'Type'); add('grades.max', 'Maximum score', 'Note maximale'); add('grades.graded', 'Graded', 'Notées'); add('grades.enter', 'Enter grades', 'Saisir les notes'); add('grades.score', 'Score', 'Note'); add('grades.status', 'Status', 'État'); add('grades.comment', 'Comment', 'Commentaire');
add('grades.save', 'Save Grades', 'Enregistrer les notes'); add('grades.saved', '{n} grade(s) saved', '{n} note(s) enregistrée(s)'); add('grades.pick', 'Choose a class and subject', 'Choisissez une classe et une matière'); add('grades.pick_text', 'Assessments will be listed here.', 'Les évaluations seront listées ici.');
add('grades.no_assessments', 'No assessments yet', 'Aucune évaluation'); add('grades.no_assessments_text', 'Click New Assessment to create one.', 'Cliquez sur Nouvelle évaluation pour en créer une.');
add('grades.need_setup', 'To record grades you need an academic year with terms, a class, and subjects assigned to the class.', 'Pour saisir des notes, il faut une année scolaire avec des périodes, une classe et des matières attribuées à la classe.');
add('grades.nothing_assigned', 'No classes or subjects are assigned to you yet.', 'Aucune classe ni matière ne vous est encore attribuée.'); add('grades.read_only', 'View only. Only the administrator can enter or change grades.', 'Lecture seule. Seul l’administrateur peut saisir ou modifier les notes.');
add('grades.missing_rule', 'Use Absent or Excused when a student did not sit the assessment. These are not counted as zero. Leave blank if not yet graded.', 'Utilisez Absent ou Excusé si l’élève n’a pas passé l’évaluation. Ces cas ne comptent pas comme zéro. Laissez vide si pas encore noté.');
add('grades.delete_assessment_confirm', 'Delete this assessment?', 'Supprimer cette évaluation ?');
add('atype.quiz', 'Quiz', 'Interrogation'); add('atype.test', 'Test', 'Devoir'); add('atype.assignment', 'Assignment', 'Travail à rendre'); add('atype.oral', 'Oral', 'Oral'); add('atype.project', 'Project', 'Projet'); add('atype.exam', 'Exam', 'Examen');

// ---- reports ----
add('reports.subtitle', 'Class results and report cards', 'Résultats de classe et bulletins'); add('reports.subtitle_family', 'Approved report cards', 'Bulletins approuvés'); add('reports.report_card', 'Report Card', 'Bulletin');
add('reports.print', 'Print / Save as PDF', 'Imprimer / Enregistrer en PDF'); add('reports.class_average', 'Class average', 'Moyenne de la classe'); add('reports.pass_mark', 'Pass mark', 'Note de passage'); add('reports.overall', 'Overall', 'Générale');
add('reports.status', 'Status', 'Statut'); add('reports.approve', 'Approve', 'Approuver'); add('reports.approve_class', 'Approve whole class', 'Approuver toute la classe'); add('reports.approve_class_confirm', 'Approve and publish the report cards of every student in this class who has results?', 'Approuver et publier les bulletins de tous les élèves de cette classe qui ont des résultats ?');
add('reports.approved', 'Report card approved', 'Bulletin approuvé'); add('reports.approved_n', '{n} report card(s) approved', '{n} bulletin(s) approuvé(s)'); add('reports.update_approved', 'Save and approve', 'Enregistrer et approuver'); add('reports.unapprove', 'Return to draft', 'Remettre en brouillon');
add('reports.admin_actions', 'Approval', 'Approbation'); add('reports.comment', 'Comment', 'Commentaire'); add('reports.comment_ph', 'Optional comment printed on the report card', 'Commentaire facultatif imprimé sur le bulletin');
add('reports.no_class', 'Choose a term and class.', 'Choisissez une période et une classe.'); add('reports.none_title', 'No report cards yet', 'Aucun bulletin pour le moment'); add('reports.sign_admin', 'Administrator', 'Administrateur'); add('reports.sign_parent', 'Parent / Guardian', 'Parent / Tuteur');
add('rstatus.draft', 'Draft', 'Brouillon'); add('rstatus.approved', 'Approved', 'Approuvé');

// ---- shop ----
add('shop.catalogue_only', 'Browse school supplies, books and uniforms.', 'Parcourez les fournitures, livres et uniformes scolaires.'); add('shop.how_to_buy', 'How to buy', 'Comment acheter');
add('shop.in_person', 'This is a catalogue only. There is no online ordering or payment. Visit the school to buy and pay in person.', 'Ceci est un catalogue uniquement. Il n’y a ni commande ni paiement en ligne. Rendez-vous à l’école pour acheter et payer sur place.');
add('shop.hours', 'Opening hours', 'Horaires d’ouverture'); add('shop.search', 'Search products', 'Rechercher des produits'); add('shop.all_categories', 'All categories', 'Toutes les catégories'); add('shop.category', 'Category', 'Catégorie');
add('shop.class_level', 'Class / grade', 'Classe / niveau'); add('shop.variant', 'Size / variant', 'Taille / variante'); add('shop.price', 'Price', 'Prix'); add('shop.availability', 'Availability', 'Disponibilité'); add('shop.details', 'Details', 'Détails');
add('shop.empty_title', 'No products found', 'Aucun produit trouvé'); add('shop.empty_text', 'Try another search or category.', 'Essayez une autre recherche ou catégorie.'); add('shop.open', 'Open catalogue', 'Ouvrir le catalogue');
add('shop.public_note', 'Prices are in FCFA (XAF). Availability may change.', 'Les prix sont en FCFA (XAF). La disponibilité peut changer.'); add('shops.choose', 'Choose a school', 'Choisissez une école'); add('shops.none', 'No schools are available yet.', 'Aucune école disponible pour le moment.');
add('cat.textbooks', 'Textbooks', 'Manuels scolaires'); add('cat.notebooks', 'Exercise books / Notebooks', 'Cahiers'); add('cat.reading_books', 'Reading books', 'Livres de lecture'); add('cat.school_supplies', 'School supplies', 'Fournitures scolaires'); add('cat.school_uniforms', 'School uniforms', 'Uniformes scolaires');
add('avail.in_stock', 'In stock', 'En stock'); add('avail.low_stock', 'Low stock', 'Stock bas'); add('avail.out_of_stock', 'Out of stock', 'Rupture de stock');

// ---- products & stock ----
add('products.add', 'Add Product', 'Ajouter un produit'); add('products.edit', 'Edit product', 'Modifier le produit'); add('products.subtitle', 'Inventory and stock movements', 'Inventaire et mouvements de stock'); add('products.search', 'Search by name or code', 'Rechercher par nom ou code');
add('products.total', 'Total products', 'Produits au total'); add('products.available', 'Available', 'Disponibles'); add('products.low', 'Low stock', 'Stock bas'); add('products.out', 'Out of stock', 'En rupture');
add('products.all_stock', 'All stock levels', 'Tous les niveaux de stock'); add('products.stock_filter', 'Stock level', 'Niveau de stock'); add('products.qty', 'Quantity', 'Quantité'); add('products.hidden', 'Hidden', 'Masqué');
add('products.adjust', 'Adjust Stock', 'Ajuster le stock'); add('products.history', 'History', 'Historique'); add('products.image', 'Product photo', 'Photo du produit'); add('products.initial_qty', 'Initial quantity', 'Quantité initiale');
add('products.threshold', 'Low-stock threshold', 'Seuil de stock bas'); add('products.threshold_hint', 'Shown as low stock at or below this number.', 'Affiché en stock bas à partir de ce nombre.'); add('products.variant_ph', 'e.g. size M', 'ex. taille M');
add('products.active_label', 'Active (can be sold)', 'Actif (peut être vendu)'); add('products.public_label', 'Show in the public catalogue', 'Afficher dans le catalogue public');
add('products.empty_title', 'No products yet', 'Aucun produit'); add('products.empty_text', 'Add the books, supplies and uniforms sold at the school.', 'Ajoutez les livres, fournitures et uniformes vendus à l’école.');
add('products.current_qty', 'Current quantity: {n}', 'Quantité actuelle : {n}'); add('products.move_type', 'Movement type', 'Type de mouvement'); add('products.reason', 'Reason', 'Motif'); add('products.reason_hint', 'Required for damaged items and adjustments.', 'Obligatoire pour les articles endommagés et les ajustements.');
add('products.change', 'Change', 'Variation'); add('products.before_after', 'Before → after', 'Avant → après'); add('products.by', 'By', 'Par'); add('products.no_moves', 'No movements yet.', 'Aucun mouvement.');
add('move.initial', 'Initial quantity', 'Quantité initiale'); add('move.restock', 'Restock', 'Réapprovisionnement'); add('move.sale', 'Sale in person', 'Vente sur place'); add('move.return', 'Customer return', 'Retour client'); add('move.damaged', 'Damaged / lost', 'Endommagé / perdu');
add('move.adjustment_in', 'Adjustment (add)', 'Ajustement (ajout)'); add('move.adjustment_out', 'Adjustment (remove)', 'Ajustement (retrait)');

// ---- settings ----
add('settings.subtitle', 'School configuration — administrator only', 'Configuration de l’école — administrateur uniquement');
add('settings.tab_school', 'School Information', 'Informations de l’école'); add('settings.tab_academic', 'Academic Settings', 'Paramètres académiques'); add('settings.tab_users', 'Users & Permissions', 'Utilisateurs et permissions');
add('settings.tab_language', 'Language & Appearance', 'Langue et apparence'); add('settings.tab_security', 'Security', 'Sécurité'); add('settings.tab_knowledge', 'School Knowledge', 'Connaissances de l’école');
add('settings.school_name', 'School name', 'Nom de l’école'); add('settings.motto', 'Motto', 'Devise'); add('settings.location', 'Location', 'Localisation'); add('settings.phone', 'Phone', 'Téléphone'); add('settings.logo', 'School logo', 'Logo de l’école'); add('settings.no_logo', 'No logo yet.', 'Pas encore de logo.');
add('settings.shop_hours', 'Shop opening hours', 'Horaires de la boutique'); add('settings.shop_hours_hint', 'Shown on the public shop page.', 'Affichés sur la page publique de la boutique.'); add('settings.shop_instructions', 'Purchase instructions', 'Instructions d’achat');
add('settings.years_terms', 'Academic years & terms', 'Années scolaires et périodes'); add('settings.current', 'Current', 'En cours'); add('settings.make_current', 'Make current', 'Définir comme en cours'); add('settings.no_terms', 'No terms yet', 'Aucune période'); add('settings.add_term', 'Add term', 'Ajouter une période');
add('settings.no_years', 'No academic years yet.', 'Aucune année scolaire.'); add('settings.new_year', 'New academic year (e.g. 2026-2027)', 'Nouvelle année scolaire (ex. 2026-2027)'); add('settings.add_year', 'Add year', 'Ajouter l’année');
add('settings.grading', 'Grading rules', 'Règles de notation'); add('settings.grading_note', 'The scale and pass mark start with common defaults (/20, pass 10). Set them to match your school’s own rules.', 'L’échelle et la note de passage démarrent avec des valeurs courantes (/20, passage 10). Réglez-les selon les règles de votre école.');
add('settings.scale', 'Grading scale (maximum)', 'Échelle de notation (maximum)'); add('settings.scale_hint', 'Averages are expressed out of this number.', 'Les moyennes sont exprimées sur ce nombre.'); add('settings.pass_mark', 'Pass mark', 'Note de passage'); add('settings.rounding', 'Decimal places', 'Décimales'); add('settings.rounding_hint', 'Rounding for averages.', 'Arrondi des moyennes.');
add('settings.ranking', 'Show class ranking on results (optional)', 'Afficher le classement sur les résultats (facultatif)'); add('settings.average_rule', 'Subject average = mean of the assessment percentages. Overall average = weighted by coefficients.', 'Moyenne de matière = moyenne des pourcentages des évaluations. Moyenne générale = pondérée par les coefficients.');
add('settings.users', 'Users', 'Utilisateurs'); add('settings.users_help', 'Create logins for teachers, parents and students. They can only view what they are allowed to.', 'Créez des comptes pour les enseignants, parents et élèves. Ils ne peuvent voir que ce qui leur est autorisé.');
add('settings.add_user', 'Add user', 'Ajouter un utilisateur'); add('settings.role', 'Role', 'Rôle'); add('settings.last_login', 'Last sign-in', 'Dernière connexion'); add('settings.you', 'You', 'Vous'); add('settings.reset', 'Reset password', 'Réinitialiser le mot de passe');
add('settings.reset_confirm', 'Reset the password of {name}? A new temporary password will be created.', 'Réinitialiser le mot de passe de {name} ? Un nouveau mot de passe temporaire sera créé.'); add('settings.no_users', 'No users yet.', 'Aucun utilisateur.');
add('settings.sole_admin', 'You are the only administrator of this school. Nobody else can change school records or settings.', 'Vous êtes le seul administrateur de cette école. Personne d’autre ne peut modifier les dossiers ou les paramètres.');
add('settings.linked_student', 'Student record', 'Dossier élève'); add('settings.linked_student_hint', 'The student login will only see this student.', 'Le compte élève ne verra que cet élève.'); add('settings.temp_note', 'A temporary password is created and shown once. The person must change it at first sign-in.', 'Un mot de passe temporaire est créé et affiché une seule fois. La personne doit le changer à la première connexion.');
add('settings.user_created', 'User created', 'Utilisateur créé'); add('settings.date_format', 'Date format', 'Format de date'); add('settings.currency', 'Currency', 'Devise'); add('settings.theme', 'Theme', 'Thème'); add('settings.theme_value', 'Professional Blue', 'Bleu professionnel');
add('security.admin_profile', 'Administrator profile', 'Profil de l’administrateur'); add('security.login_history', 'Recent sign-ins', 'Connexions récentes'); add('security.login_ok', 'Signed in', 'Connecté'); add('security.login_failed', 'Failed attempt', 'Tentative échouée');
add('security.backup', 'Backup & recovery', 'Sauvegarde et restauration'); add('security.backup_text', 'The database file and uploaded files are in the "data" folder of the JAO project. Copy that whole folder regularly to a safe place, and test restoring it. See the README for the exact steps.', 'Le fichier de base de données et les fichiers téléversés se trouvent dans le dossier « data » du projet JAO. Copiez régulièrement tout ce dossier dans un endroit sûr et testez la restauration. Voir le README pour les étapes exactes.');
add('security.session_text', 'Sessions end after 8 hours without activity.', 'Les sessions se terminent après 8 heures d’inactivité.'); add('security.audit', 'Audit log', 'Journal d’audit');
add('audit.who', 'Who', 'Qui'); add('audit.action', 'Action', 'Action'); add('audit.record', 'Record', 'Enregistrement'); add('audit.none', 'No entries yet.', 'Aucune entrée.');
for (const [k, en, fr] of [['school_created', 'School created', 'École créée'], ['settings_updated', 'Settings updated', 'Paramètres modifiés'], ['logo_updated', 'Logo updated', 'Logo modifié'], ['year_created', 'Academic year created', 'Année scolaire créée'],
  ['year_set_current', 'Current year changed', 'Année en cours modifiée'], ['term_created', 'Term created', 'Période créée'], ['user_created', 'User created', 'Utilisateur créé'], ['user_updated', 'User updated', 'Utilisateur modifié'], ['password_reset', 'Password reset', 'Mot de passe réinitialisé'],
  ['password_changed', 'Password changed', 'Mot de passe modifié'], ['student_created', 'Student registered', 'Élève inscrit'], ['student_updated', 'Student updated', 'Élève modifié'], ['student_archived', 'Student archived', 'Élève archivé'],
  ['guardian_account_linked', 'Parent login linked', 'Compte parent lié'], ['class_created', 'Class created', 'Classe créée'], ['class_updated', 'Class updated', 'Classe modifiée'], ['class_deactivated', 'Class deactivated', 'Classe désactivée'],
  ['class_subjects_updated', 'Class subjects updated', 'Matières de la classe modifiées'], ['subject_created', 'Subject created', 'Matière créée'], ['subject_updated', 'Subject updated', 'Matière modifiée'], ['subject_deactivated', 'Subject deactivated', 'Matière désactivée'],
  ['assessment_created', 'Assessment created', 'Évaluation créée'], ['assessment_deleted', 'Assessment deleted', 'Évaluation supprimée'], ['grade_entered', 'Grade entered', 'Note saisie'], ['grade_updated', 'Grade changed', 'Note modifiée'], ['grade_deleted', 'Grade removed', 'Note supprimée'],
  ['report_approved', 'Report card approved', 'Bulletin approuvé'], ['report_unapproved', 'Report card returned to draft', 'Bulletin remis en brouillon'], ['class_reports_approved', 'Class report cards approved', 'Bulletins de classe approuvés'],
  ['product_created', 'Product created', 'Produit créé'], ['product_updated', 'Product updated', 'Produit modifié'], ['product_deactivated', 'Product deactivated', 'Produit désactivé'], ['product_price_changed', 'Price changed', 'Prix modifié'], ['stock_changed', 'Stock changed', 'Stock modifié'],
  ['knowledge_created', 'Knowledge entry created', 'Entrée de connaissances créée'], ['knowledge_updated', 'Knowledge entry updated', 'Entrée de connaissances modifiée'], ['knowledge_published', 'Knowledge entry published', 'Entrée de connaissances publiée'],
  ['knowledge_draft', 'Knowledge entry unpublished', 'Entrée de connaissances dépubliée'], ['knowledge_archived', 'Knowledge entry archived', 'Entrée de connaissances archivée'], ['knowledge_deleted', 'Knowledge entry deleted', 'Entrée de connaissances supprimée']]) add(`audit.${k}`, en, fr);

// ---- knowledge management ----
add('knowledge.help', 'Write the approved facts DOUDOUS² may use about the school. Only published entries are used.', 'Rédigez les faits approuvés que DOUDOUS² peut utiliser sur l’école. Seules les entrées publiées sont utilisées.'); add('knowledge.add', 'Add Entry', 'Ajouter une entrée'); add('knowledge.edit', 'Edit entry', 'Modifier l’entrée');
add('knowledge.title', 'Title', 'Titre'); add('knowledge.category', 'Category', 'Catégorie'); add('knowledge.language', 'Language', 'Langue'); add('knowledge.period', 'Date or period', 'Date ou période'); add('knowledge.period_ph', 'e.g. 1999', 'ex. 1999');
add('knowledge.text', 'Text', 'Texte'); add('knowledge.text_hint', 'Write only confirmed facts.', 'N’écrivez que des faits confirmés.'); add('knowledge.source', 'Source note', 'Note de source'); add('knowledge.source_hint', 'Where the information comes from, so it can be checked.', 'D’où vient l’information, pour pouvoir la vérifier.');
add('knowledge.draft_note', 'New entries are saved as drafts. Click Publish to let DOUDOUS² use them.', 'Les nouvelles entrées sont enregistrées en brouillon. Cliquez sur Publier pour que DOUDOUS² puisse les utiliser.');
add('knowledge.publish', 'Publish', 'Publier'); add('knowledge.unpublish', 'Unpublish', 'Dépublier'); add('knowledge.archive', 'Archive', 'Archiver'); add('knowledge.delete_confirm', 'Delete this entry permanently?', 'Supprimer cette entrée définitivement ?');
add('knowledge.empty_title', 'No entries yet', 'Aucune entrée'); add('knowledge.empty_text', 'Add the school history, motto, mission and other approved facts.', 'Ajoutez l’histoire de l’école, la devise, la mission et d’autres faits approuvés.');
add('knowledge.preview', 'Preview DOUDOUS²’s answer', 'Aperçu de la réponse de DOUDOUS²'); add('knowledge.preview_help', 'Test what a visitor would be told, using published entries only.', 'Testez ce qu’un visiteur obtiendrait, en utilisant uniquement les entrées publiées.'); add('knowledge.preview_ph', 'e.g. When was the school founded?', 'ex. Quand l’école a-t-elle été fondée ?'); add('knowledge.test', 'Test', 'Tester');
for (const [k, en, fr] of [['history', 'History', 'Histoire'], ['identity', 'Identity & values', 'Identité et valeurs'], ['development', 'Development', 'Développement'], ['achievements', 'Achievements', 'Réalisations'], ['leadership', 'Leadership', 'Direction'], ['traditions', 'Traditions & activities', 'Traditions et activités'], ['general', 'General information', 'Informations générales']]) add(`kcat.${k}`, en, fr);
add('kstatus.draft', 'Draft', 'Brouillon'); add('kstatus.published', 'Published', 'Publié'); add('kstatus.archived', 'Archived', 'Archivé');

// ---- DOUDOUS² ----
add('dudus.open', 'Open DOUDOUS² assistant', 'Ouvrir l’assistant DOUDOUS²'); add('dudus.greeting', 'Hello! I’m DOUDOUS². Ask me how to use JAO or about the school.', 'Bonjour ! Je suis DOUDOUS². Demandez-moi comment utiliser JAO ou posez-moi des questions sur l’école.');
add('dudus.placeholder', 'Type your question…', 'Saisissez votre question…'); add('dudus.send', 'Send', 'Envoyer'); add('dudus.thinking', 'Thinking…', 'Réflexion…'); add('dudus.clear', 'Clear conversation', 'Effacer la conversation');
add('dudus.disclaimer', 'DOUDOUS² answers only from approved information and can make mistakes. It never shows private records.', 'DOUDOUS² répond uniquement à partir d’informations approuvées et peut se tromper. Il n’affiche jamais de dossiers privés.');
add('dudus.mode_kb', 'AI model not configured — answering from the approved knowledge base only.', 'Modèle d’IA non configuré — réponses uniquement à partir de la base de connaissances approuvée.'); add('dudus.mode_ai', 'AI model connected — answers use approved content only.', 'Modèle d’IA connecté — les réponses utilisent uniquement le contenu approuvé.'); add('dudus.mode_public', 'Public information only.', 'Informations publiques uniquement.');
add('dudus.q_register', 'How do I register a student?', 'Comment inscrire un élève ?'); add('dudus.q_grades', 'How do I enter grades?', 'Comment saisir les notes ?'); add('dudus.q_report', 'How do I download a report card?', 'Comment télécharger un bulletin ?');
add('dudus.q_shop', 'How do I buy from the school shop?', 'Comment acheter à la boutique ?'); add('dudus.q_hist', 'When was the school founded?', 'Quand l’école a-t-elle été fondée ?');

// ---- platform owner ----
add('platform.owner', 'JAO Platform', 'Plateforme JAO'); add('platform.subtitle', 'Registered schools and registration requests', 'Écoles inscrites et demandes d’inscription'); add('platform.privacy', 'As super administrator you manage school accounts only. You cannot see any school’s student, guardian or grade records.', 'En tant que super administrateur, vous gérez uniquement les comptes d’écoles. Vous ne pouvez voir aucun dossier d’élève, de tuteur ou de notes.');
add('platform.schools', 'Schools', 'Écoles'); add('platform.active', 'Active', 'Actives'); add('platform.pending', 'Pending requests', 'Demandes en attente'); add('platform.suspended', 'Suspended', 'Suspendues');
add('platform.requests', 'Registration requests', 'Demandes d’inscription'); add('platform.no_requests', 'No requests.', 'Aucune demande.'); add('platform.registered', 'Registered schools', 'Écoles inscrites');
add('platform.approve', 'Approve', 'Approuver'); add('platform.approved', 'School approved', 'École approuvée'); add('platform.reject', 'Reject', 'Refuser'); add('platform.reject_confirm', 'Reject this request?', 'Refuser cette demande ?');
add('platform.suspend', 'Suspend', 'Suspendre'); add('platform.activate', 'Activate', 'Activer'); add('platform.suspend_confirm', 'Suspend {name}? Its users will be signed out and cannot sign in.', 'Suspendre {name} ? Ses utilisateurs seront déconnectés et ne pourront plus se connecter.');
add('platform.create', 'Create a school account', 'Créer un compte d’école'); add('platform.create_btn', 'Create school', 'Créer l’école'); add('platform.created', 'School created', 'École créée');
add('req.pending', 'Pending', 'En attente'); add('req.approved', 'Approved', 'Approuvée'); add('req.rejected', 'Rejected', 'Refusée'); add('sstatus.active', 'Active', 'Active'); add('sstatus.suspended', 'Suspended', 'Suspendue');

// ---- Multi-school portal ----
add('portal.title', 'JAO – MULTI-SCHOOL MANAGEMENT SYSTEM', 'JAO – SYSTÈME DE GESTION MULTI-ÉCOLES');
add('portal.subtitle', 'One platform, many schools. Every school has its own private management system.', 'Une plateforme, plusieurs écoles. Chaque école dispose de son propre système de gestion privé.');
add('portal.enter_title', 'Enter an Existing School', 'Accéder à une école existante');
add('portal.enter_text', 'Find your school by its name or its unique school code, then sign in.', 'Trouvez votre école par son nom ou son code unique, puis connectez-vous.');
add('portal.search_label', 'School name or school code', 'Nom ou code de l’école');
add('portal.search_placeholder', 'School name or code (e.g. JAO-0001)', 'Nom ou code de l’école (ex. JAO-0001)');
add('portal.type_more', 'Type at least 2 characters.', 'Saisissez au moins 2 caractères.');
add('portal.none_found', 'No active school found. Check the name or code.', 'Aucune école active trouvée. Vérifiez le nom ou le code.');
add('portal.create_title', 'Create a New School', 'Créer une nouvelle école');
add('portal.create_text', 'Register your school and get its own independent management system.', 'Inscrivez votre école et obtenez son propre système de gestion indépendant.');
add('portal.create_btn', 'Create a New School', 'Créer une nouvelle école');
add('portal.super_link', 'JAO super administrator', 'Super administrateur JAO');
add('portal.super_title', 'Super Administrator', 'Super administrateur');
add('portal.super_text', 'Sign in to manage the JAO platform and its schools.', 'Connectez-vous pour gérer la plateforme JAO et ses écoles.');
add('portal.switch_school', 'Switch school', 'Changer d’école');
add('portal.not_found', 'School not found', 'École introuvable');
add('portal.not_found_text', 'This school does not exist. Search again from the first page.', 'Cette école n’existe pas. Relancez la recherche depuis la première page.');
add('portal.state_pending', 'This school is waiting for approval by the JAO super administrator. You can sign in once it is approved.', 'Cette école attend l’approbation du super administrateur JAO. Vous pourrez vous connecter après approbation.');
add('portal.state_rejected', 'This school registration was not approved. Please contact JAO.', 'L’inscription de cette école n’a pas été approuvée. Veuillez contacter JAO.');
add('portal.state_suspended', 'This school is currently deactivated. Please contact JAO.', 'Cette école est actuellement désactivée. Veuillez contacter JAO.');
add('portal.choose', 'Choose…', 'Choisir…');
add('portal.register_title', 'Create a New School', 'Créer une nouvelle école');
add('portal.register_text', 'Fill in the form. Your school gets its own private system and its own administrator account.', 'Remplissez le formulaire. Votre école reçoit son propre système privé et son propre compte administrateur.');
add('portal.sec_school', 'School information', 'Informations sur l’école');
add('portal.sec_admin', 'School administrator', 'Administrateur de l’école');
add('portal.school_name', 'Official school name', 'Nom officiel de l’école');
add('portal.school_type', 'School type', 'Type d’école');
add('portal.address', 'School address', 'Adresse de l’école');
add('portal.location', 'Location (town / region)', 'Localisation (ville / région)');
add('portal.location_ph', 'e.g. Douala, Littoral', 'ex. Douala, Littoral');
add('portal.school_email', 'School email', 'E-mail de l’école');
add('portal.school_phone', 'School telephone', 'Téléphone de l’école');
add('portal.logo', 'School logo', 'Logo de l’école');
add('portal.logo_hint', 'Optional. JPG, PNG or WebP, up to 2 MB.', 'Facultatif. JPG, PNG ou WebP, 2 Mo maximum.');
add('portal.logo_none', 'No logo', 'Aucun logo');
add('portal.admin_name', 'Administrator full name', 'Nom complet de l’administrateur');
add('portal.admin_email', 'Administrator email', 'E-mail de l’administrateur');
add('portal.register_btn', 'Create my school', 'Créer mon école');
add('portal.created_title', 'School created', 'École créée');
add('portal.created_name', '{name} has been registered. Its unique school code is:', '{name} a été enregistrée. Son code d’école unique est :');
add('portal.created_code_help', 'Keep this code. Anyone from your school can use it, or the school name, to find the sign-in page.', 'Conservez ce code. Toute personne de votre école peut l’utiliser, ou utiliser le nom de l’école, pour trouver la page de connexion.');
add('portal.created_pending', 'Your administrator account is ready, but the school must be approved by the JAO super administrator before you can sign in.', 'Votre compte administrateur est prêt, mais l’école doit être approuvée par le super administrateur JAO avant votre connexion.');
add('portal.created_active', 'Your school is active. You can sign in now.', 'Votre école est active. Vous pouvez vous connecter maintenant.');
add('portal.go_signin', 'Go to the school sign-in page', 'Aller à la page de connexion de l’école');
add('portal.school_code', 'School code', 'Code de l’école');
add('portal.code_hint', 'Unique and permanent. Share it so your school can be found.', 'Unique et permanent. Partagez-le pour que votre école soit retrouvée.');
add('platform.filter', 'Filter schools by name, code or town', 'Filtrer les écoles par nom, code ou ville');
add('platform.view', 'View', 'Voir');
add('platform.inactive', 'Deactivated', 'Désactivées');
add('platform.none', 'No schools found.', 'Aucune école trouvée.');
add('platform.counts', 'Totals', 'Totaux');
add('platform.teachers', 'teachers', 'enseignants');
add('platform.activated', 'School activated', 'École activée');
add('platform.state_active', 'Active', 'Active');
add('platform.state_suspended', 'Deactivated', 'Désactivée');
add('platform.state_pending', 'Awaiting approval', 'En attente d’approbation');
add('platform.state_rejected', 'Rejected', 'Refusée');
add('stype.nursery', 'Nursery school', 'École maternelle');
add('stype.primary', 'Primary school', 'École primaire');
add('stype.nursery_primary', 'Nursery & primary', 'Maternelle et primaire');
add('stype.secondary_general', 'Secondary school (general)', 'Lycée / collège (général)');
add('stype.secondary_technical', 'Secondary school (technical)', 'Lycée / collège (technique)');
add('stype.vocational', 'Vocational / training centre', 'Centre de formation professionnelle');
add('stype.higher_education', 'Higher education', 'Enseignement supérieur');
add('stype.other', 'Other', 'Autre');

add('reset.title', 'Choose a new password', 'Choisissez un nouveau mot de passe');
add('reset.for', 'Administrator of {school} ({email}). Only you will know this password.', 'Administrateur de {school} ({email}). Vous seul connaîtrez ce mot de passe.');
add('reset.new_password', 'New password', 'Nouveau mot de passe');
add('reset.save', 'Save new password', 'Enregistrer le nouveau mot de passe');
add('reset.done', 'Password changed', 'Mot de passe modifié');
add('reset.done_text', 'You were signed out everywhere else. Sign in with your new password.', 'Vous avez été déconnecté partout ailleurs. Connectez-vous avec votre nouveau mot de passe.');
add('reset.go_signin', 'Go to sign in', 'Aller à la connexion');
add('reset.invalid', 'This link is not valid', 'Ce lien n’est pas valide');
add('reset.invalid_text', 'It may have expired, been used already, or been replaced by a newer link. Ask the JAO super administrator for a new one.', 'Il a peut-être expiré, déjà été utilisé ou remplacé par un lien plus récent. Demandez-en un nouveau au super administrateur JAO.');
add('platform.reset_pw', 'Reset password', 'Réinitialiser le mot de passe');
add('platform.reset_confirm', 'Create a one-time password-reset link for the administrator of {name}? Any older link stops working.', 'Créer un lien de réinitialisation à usage unique pour l’administrateur de {name} ? Les anciens liens cesseront de fonctionner.');
add('platform.reset_ready', 'Password-reset link ready', 'Lien de réinitialisation prêt');
add('platform.reset_link', 'One-time link (shown only once)', 'Lien à usage unique (affiché une seule fois)');
add('platform.reset_valid', 'Valid for', 'Valable');
add('platform.reset_hours', '{n} hours, one use', '{n} heures, un seul usage');
add('acad.coef_missing', 'Coefficient not set', 'Coefficient non défini');
add('acad.coef_ph', 'Not set', 'Non défini');
add('acad.coefs_missing_notice', 'The overall average is not shown because the coefficient is not set for: {subjects}. Set it in Classes → Assign subjects.', 'La moyenne générale n’est pas affichée car le coefficient n’est pas défini pour : {subjects}. Définissez-le dans Classes → Attribuer des matières.');
add('reports.skipped_n', '{n} report card(s) skipped: coefficient missing.', '{n} bulletin(s) ignoré(s) : coefficient manquant.');
add('subjects.default_coef_hint', 'Optional. Leave empty if unknown. Each class can have its own coefficient.', 'Facultatif. Laissez vide si inconnu. Chaque classe peut avoir son propre coefficient.');

// ---- error messages (server codes) ----
const ERR = {
  reset_invalid: ['This reset link is not valid or has expired.', 'Ce lien de réinitialisation n’est pas valide ou a expiré.'],
  coefficients_missing: ['Cannot approve: a coefficient is missing for a graded subject. Set coefficients first.', 'Approbation impossible : un coefficient est manquant pour une matière notée. Définissez d’abord les coefficients.'],
  school_pending: ['Your school is waiting for approval by the JAO super administrator.', 'Votre école attend l’approbation du super administrateur JAO.'],
  school_rejected: ['This school registration was not approved.', 'L’inscription de cette école n’a pas été approuvée.'],
  school_suspended: ['This school is currently deactivated. Please contact JAO.', 'Cette école est actuellement désactivée. Veuillez contacter JAO.'],
  school_name_taken: ['A school with this name already exists.', 'Une école portant ce nom existe déjà.'],
  invalid_school_type: ['Choose a school type.', 'Choisissez un type d’école.'],
  address_required: ['The school address is required.', 'L’adresse de l’école est obligatoire.'],
  location_required: ['The location is required.', 'La localisation est obligatoire.'],
  generic: ['Something went wrong. Please try again.', 'Une erreur est survenue. Veuillez réessayer.'], network: ['Cannot reach the server. Check your connection.', 'Impossible de joindre le serveur. Vérifiez votre connexion.'],
  required: ['Required', 'Obligatoire'], password_mismatch: ['The passwords do not match.', 'Les mots de passe ne correspondent pas.'],
  unauthenticated: ['Please sign in.', 'Veuillez vous connecter.'], forbidden: ['You are not allowed to do this.', 'Vous n’avez pas l’autorisation de faire cela.'], not_found: ['Not found, or you do not have access.', 'Introuvable, ou vous n’y avez pas accès.'],
  invalid_json: ['Invalid request.', 'Requête invalide.'], too_large: ['The file is too large.', 'Le fichier est trop volumineux.'], method_not_allowed: ['Not allowed.', 'Non autorisé.'], duplicate: ['This already exists (duplicate).', 'Cet élément existe déjà (doublon).'], invalid_data: ['Some information is invalid.', 'Certaines informations sont invalides.'],
  server_error: ['Server error. Please try again.', 'Erreur du serveur. Veuillez réessayer.'], password_change_required: ['Please change your temporary password first.', 'Veuillez d’abord changer votre mot de passe temporaire.'],
  invalid_credentials: ['Incorrect email or password.', 'E-mail ou mot de passe incorrect.'], too_many_attempts: ['Too many attempts. Please wait and try again.', 'Trop de tentatives. Veuillez patienter puis réessayer.'], wrong_password: ['The current password is incorrect.', 'Le mot de passe actuel est incorrect.'],
  password_too_short: ['The password must have at least 10 characters.', 'Le mot de passe doit comporter au moins 10 caractères.'], password_weak: ['The password needs letters and numbers.', 'Le mot de passe doit contenir des lettres et des chiffres.'],
  invalid_language: ['Invalid language.', 'Langue invalide.'], invalid_email: ['Enter a valid email address.', 'Saisissez une adresse e-mail valide.'], invalid_phone: ['Enter a valid phone number.', 'Saisissez un numéro de téléphone valide.'], school_name_required: ['School name is required.', 'Le nom de l’école est obligatoire.'],
  name_required: ['Name is required.', 'Le nom est obligatoire.'], email_in_use: ['This email is already used.', 'Cet e-mail est déjà utilisé.'], invalid_status: ['Invalid status.', 'Statut invalide.'], invalid_image: ['This image cannot be used.', 'Cette image est inutilisable.'],
  image_too_large: ['The image is larger than 2 MB.', 'L’image dépasse 2 Mo.'], invalid_image_type: ['Use a JPG, PNG or WebP image.', 'Utilisez une image JPG, PNG ou WebP.'], invalid_year: ['Choose a valid academic year.', 'Choisissez une année scolaire valide.'], invalid_role: ['Invalid role.', 'Rôle invalide.'],
  invalid_student: ['Choose a valid student.', 'Choisissez un élève valide.'], invalid_grading_settings: ['The scale, pass mark or rounding is not valid (pass mark cannot exceed the scale).', 'L’échelle, la note de passage ou l’arrondi n’est pas valide (la note de passage ne peut pas dépasser l’échelle).'],
  full_name_required: ['Full name is required.', 'Le nom complet est obligatoire.'], invalid_dob: ['Enter a valid date of birth (not in the future).', 'Saisissez une date de naissance valide (pas dans le futur).'], invalid_gender: ['Invalid gender.', 'Genre invalide.'], invalid_enrollment_date: ['Enter a valid enrollment date.', 'Saisissez une date d’inscription valide.'],
  class_required: ['Choose a class.', 'Choisissez une classe.'], class_year_mismatch: ['The class does not belong to the chosen academic year.', 'La classe n’appartient pas à l’année scolaire choisie.'], class_full: ['This class has reached its maximum capacity.', 'Cette classe a atteint sa capacité maximale.'],
  guardian_required: ['Add at least one parent or guardian.', 'Ajoutez au moins un parent ou tuteur.'], too_many_guardians: ['Too many guardians.', 'Trop de tuteurs.'], invalid_guardian: ['Invalid guardian.', 'Tuteur invalide.'], relationship_required: ['Relationship is required.', 'Le lien de parenté est obligatoire.'],
  guardian_name_required: ['Guardian name is required.', 'Le nom du tuteur est obligatoire.'], one_primary_only: ['Choose only one primary contact.', 'Choisissez un seul contact principal.'], invalid_user: ['Invalid user.', 'Utilisateur invalide.'], invalid_teacher: ['Choose a valid teacher.', 'Choisissez un enseignant valide.'],
  invalid_capacity: ['Capacity must be between 1 and 500.', 'La capacité doit être comprise entre 1 et 500.'], invalid_subject: ['Invalid or repeated subject.', 'Matière invalide ou répétée.'], invalid_coefficient: ['Coefficient must be greater than 0.', 'Le coefficient doit être supérieur à 0.'],
  subject_has_assessments: ['This subject already has assessments in the class and cannot be removed from it.', 'Cette matière a déjà des évaluations dans la classe et ne peut pas en être retirée.'], code_required: ['Code is required.', 'Le code est obligatoire.'], invalid_code: ['Use letters, numbers, dash or underscore only.', 'Utilisez uniquement lettres, chiffres, tiret ou tiret bas.'],
  invalid_reference: ['Choose a valid class, subject and term.', 'Choisissez une classe, une matière et une période valides.'], subject_not_in_class: ['This subject is not assigned to the class yet (Classes → Assign subjects).', 'Cette matière n’est pas encore attribuée à la classe (Classes → Attribuer des matières).'],
  term_year_mismatch: ['The term belongs to a different academic year.', 'La période appartient à une autre année scolaire.'], invalid_max_score: ['Maximum score must be greater than 0.', 'La note maximale doit être supérieure à 0.'], invalid_date: ['Enter a valid date.', 'Saisissez une date valide.'], invalid_type: ['Invalid type.', 'Type invalide.'],
  assessment_has_grades: ['This assessment has grades and cannot be deleted.', 'Cette évaluation contient des notes et ne peut pas être supprimée.'], too_many_entries: ['Too many entries at once.', 'Trop d’entrées à la fois.'], score_out_of_range: ['The score must be between 0 and {max}.', 'La note doit être comprise entre 0 et {max}.'],
  invalid_term: ['Choose a valid term.', 'Choisissez une période valide.'], no_results_to_approve: ['There are no grades to approve for this term.', 'Il n’y a aucune note à approuver pour cette période.'], invalid_category: ['Choose a valid category.', 'Choisissez une catégorie valide.'],
  invalid_price: ['Enter a whole price in FCFA (0 or more).', 'Saisissez un prix entier en FCFA (0 ou plus).'], invalid_threshold: ['Invalid low-stock threshold.', 'Seuil de stock bas invalide.'], invalid_quantity: ['Enter a whole quantity of 1 or more.', 'Saisissez une quantité entière d’au moins 1.'],
  invalid_movement_type: ['Invalid movement type.', 'Type de mouvement invalide.'], reason_required: ['Please give a reason.', 'Veuillez indiquer un motif.'], insufficient_stock: ['Not enough stock for this movement.', 'Stock insuffisant pour ce mouvement.'],
  message_required: ['Type a question first.', 'Saisissez d’abord une question.'], title_required: ['Title is required.', 'Le titre est obligatoire.'], text_required: ['Text is required.', 'Le texte est obligatoire.'],
  comment_required: ['Please give a reason.', 'Veuillez indiquer un motif.'], location_required: ['Location is required.', 'Le lieu est obligatoire.'],
  invalid_member: ['Choose council members who hold the council member permission.', 'Choisissez des membres du conseil ayant le droit « membre du conseil ».'], invalid_incident: ['Choose incidents of this student only.', 'Choisissez uniquement des incidents de cet élève.'],
  case_exists: ['This student is already on this meeting agenda.', 'Cet élève figure déjà à l’ordre du jour de cette réunion.'], meeting_cancelled: ['This meeting is cancelled.', 'Cette réunion est annulée.'], decision_locked: ['This decision has been approved and can no longer be changed.', 'Cette décision a été approuvée et ne peut plus être modifiée.'],
  decision_exists: ['A case with a decision cannot be removed.', 'Un dossier ayant une décision ne peut pas être retiré.'], decision_required: ['Write the decision.', 'Rédigez la décision.'], invalid_approver: ['Choose a person authorised to approve decisions.', 'Choisissez une personne autorisée à approuver les décisions.'],
  invalid_sanction_type: ['Choose a valid sanction.', 'Choisissez une sanction valide.'], invalid_duration: ['Enter a duration in days (1 to 365).', 'Saisissez une durée en jours (1 à 365).'], invalid_decision: ['Choose an approved decision about this student.', 'Choisissez une décision approuvée concernant cet élève.'],
  name_in_use: ['This name already exists.', 'Ce nom existe déjà.'],
  invalid_time: ['Enter a valid time.', 'Saisissez une heure valide.'], description_required: ['Please describe what happened (at least a few words).', 'Veuillez décrire ce qui s’est passé (quelques mots au moins).'],
  invalid_category: ['Choose a valid type of misconduct.', 'Choisissez un type de faute valide.'], note_required: ['Please write a note.', 'Veuillez écrire une note.'],
  file_too_large: ['The file is larger than 3 MB.', 'Le fichier dépasse 3 Mo.'], invalid_file_type: ['Use a PDF, JPG, PNG or WebP file.', 'Utilisez un fichier PDF, JPG, PNG ou WebP.'],
  invalid_file: ['The file could not be read.', 'Le fichier n’a pas pu être lu.'], too_many_files: ['An incident can have at most 10 documents.', 'Un incident peut avoir au maximum 10 documents.'],
};
for (const [k, [en, fr]] of Object.entries(ERR)) add(`err.${k}`, en, fr);

// ---- Discipline module (phase 1: setup) ----
add('nav.discipline', 'Discipline', 'Discipline');
add('common.add', 'Add', 'Ajouter'); add('common.none', 'Nothing here yet.', 'Rien pour le moment.');
add('disc.subtitle', 'Student conduct, disciplinary council and parent convocations.', 'Conduite des élèves, conseil de discipline et convocation des parents.');
add('disc.confidential_note', 'Disciplinary information is confidential. Only people authorised by the school administration can see it.', 'Les informations disciplinaires sont confidentielles. Seules les personnes autorisées par l’administration de l’école peuvent les consulter.');
add('disc.tab_lists', 'Categories & sanctions', 'Catégories et sanctions'); add('disc.tab_people', 'Who can do what', 'Qui peut faire quoi'); add('disc.tab_report', 'Report card', 'Bulletin'); add('disc.tab_mine', 'My access', 'Mes droits');
add('disc.categories', 'Types of misconduct', 'Types de faute'); add('disc.categories_hint', 'Your school can rename, add or switch off any of these.', 'Votre école peut renommer, ajouter ou désactiver chacun de ces éléments.');
add('disc.sanction_types', 'Sanctions', 'Sanctions'); add('disc.sanctions_hint', 'A list of choices. No sanction is ever applied automatically: each one needs approval from an authorised person.', 'Une liste de choix. Aucune sanction n’est appliquée automatiquement : chacune doit être approuvée par une personne autorisée.');
add('disc.minor', 'Minor', 'Mineure'); add('disc.serious', 'Serious', 'Grave'); add('disc.severity', 'Seriousness', 'Gravité'); add('disc.has_duration', 'Has a duration', 'A une durée');
add('disc.off', 'Off', 'Désactivé'); add('disc.switch_off', 'Switch off', 'Désactiver'); add('disc.switch_on', 'Switch on', 'Activer');
add('disc.people', 'Who can do what', 'Qui peut faire quoi'); add('disc.people_note', 'The administrator can do everything. Teachers can report incidents. Give other teachers extra permissions below.', 'L’administrateur peut tout faire. Les enseignants peuvent signaler des incidents. Accordez ci-dessous des droits supplémentaires aux autres enseignants.');
add('disc.no_staff', 'No teachers yet. Create teacher accounts in Settings > Users.', 'Aucun enseignant pour le moment. Créez des comptes enseignants dans Paramètres > Utilisateurs.');
add('disc.perm_report_incidents', 'Report disciplinary incidents', 'Signaler des incidents disciplinaires');
add('disc.perm_manage_discipline', 'Discipline officer: manage incidents and follow-up', 'Responsable de la discipline : gérer les incidents et le suivi');
add('disc.perm_council_member', 'Council member: access assigned council cases', 'Membre du conseil : accéder aux dossiers du conseil qui lui sont confiés');
add('disc.perm_approve_decisions', 'Principal: approve official decisions and convocations', 'Chef d’établissement : approuver les décisions et convocations officielles');
add('disc.your_access', 'What you can do in Discipline', 'Ce que vous pouvez faire dans Discipline'); add('disc.access_note', 'Ask the school administrator if you need more access.', 'Demandez à l’administrateur de l’école si vous avez besoin de plus de droits.');
add('disc.report_title', 'Disciplinary information on report cards', 'Informations disciplinaires sur le bulletin');
add('disc.report_note', 'Both options are OFF by default. Confidential proceedings and council discussions are never printed on a report card. Only information that has been approved is shown.', 'Les deux options sont désactivées par défaut. Les procédures confidentielles et les débats du conseil ne figurent jamais sur le bulletin. Seules les informations approuvées sont affichées.');
add('disc.report_conduct', 'Show the conduct assessment and approved observations', 'Afficher l’appréciation de conduite et les observations approuvées'); add('disc.report_decisions', 'Show approved council decisions', 'Afficher les décisions approuvées du conseil');

// ---- Discipline module (phase 2: incidents and student history) ----
add('common.all', 'All', 'Tous'); add('common.change', 'Change', 'Changer'); add('common.remove', 'Remove', 'Retirer');
add('disc.tab_incidents', 'Incidents', 'Incidents'); add('disc.history', 'Disciplinary history', 'Historique disciplinaire'); add('disc.back_student', 'Student profile', 'Fiche de l’élève');
add('disc.new_incident', 'Report an incident', 'Signaler un incident'); add('disc.incident_no', 'Incident #{n}', 'Incident n° {n}'); add('disc.incident_saved', 'Incident recorded.', 'Incident enregistré.');
add('disc.count', '{n} incident(s)', '{n} incident(s)'); add('disc.no_incidents', 'No incidents found.', 'Aucun incident trouvé.'); add('disc.search_ph', 'Search by student name or ID…', 'Rechercher par nom ou matricule…');
add('disc.status', 'Status', 'Statut'); add('disc.category', 'Type of misconduct', 'Type de faute'); add('disc.from', 'From', 'Du'); add('disc.to', 'To', 'Au');
add('disc.status_reported', 'Reported', 'Signalé'); add('disc.status_under_review', 'Under review', 'En cours d’examen'); add('disc.status_action_taken', 'Action taken', 'Mesure prise'); add('disc.status_closed', 'Closed', 'Clôturé'); add('disc.status_dismissed', 'Dismissed', 'Classé sans suite');
add('disc.reported_by', 'Reported by', 'Signalé par'); add('disc.student', 'Student', 'Élève'); add('disc.find_student', 'Type a name or ID to find the student…', 'Saisissez un nom ou un matricule pour trouver l’élève…');
add('disc.no_student_found', 'No student found among the students you may report on.', 'Aucun élève trouvé parmi ceux que vous pouvez signaler.'); add('disc.choose_student', 'Choose a student first.', 'Choisissez d’abord un élève.');
add('disc.date', 'Date of incident', 'Date de l’incident'); add('disc.time', 'Time', 'Heure'); add('disc.description', 'What happened', 'Description des faits');
add('disc.description_hint', 'Describe the facts only: what, where, who. Do not add opinions.', 'Décrivez uniquement les faits : quoi, où, qui. N’ajoutez pas d’opinions.');
add('disc.witnesses', 'Witnesses', 'Témoins'); add('disc.add_witness', 'Add a witness', 'Ajouter un témoin'); add('disc.witness_name', 'Witness name', 'Nom du témoin'); add('disc.witness_note', 'What they saw (optional)', 'Ce qu’il/elle a vu (facultatif)');
add('disc.locked', 'This incident is under review and can no longer be edited by the person who reported it.', 'Cet incident est en cours d’examen : la personne qui l’a signalé ne peut plus le modifier.');
add('disc.documents', 'Supporting documents', 'Pièces justificatives'); add('disc.no_documents', 'No documents.', 'Aucun document.'); add('disc.add_document', 'Add a document', 'Ajouter un document');
add('disc.doc_hint', 'PDF, JPG, PNG or WebP, up to 3 MB. Documents are private and only shown to authorised people.', 'PDF, JPG, PNG ou WebP, 3 Mo maximum. Les documents sont privés et visibles uniquement par les personnes autorisées.');
add('disc.docs_after_save', 'You can attach documents after saving the incident.', 'Vous pourrez joindre des documents après l’enregistrement de l’incident.'); add('disc.remove_doc', 'Remove this document?', 'Retirer ce document ?');
add('disc.incidents', 'Incidents', 'Incidents'); add('disc.followups', 'Follow-up and conduct progress', 'Suivi et évolution de la conduite'); add('disc.no_followups', 'No follow-up recorded yet.', 'Aucun suivi enregistré pour le moment.');
add('disc.add_followup', 'Record a follow-up', 'Enregistrer un suivi'); add('disc.followup', 'Follow-up note', 'Note de suivi'); add('disc.followup_ph', 'What was done or agreed with the student or parent?', 'Qu’a-t-on fait ou convenu avec l’élève ou le parent ?');
add('disc.trend', 'Conduct trend', 'Évolution de la conduite'); add('disc.trend_none', 'Not specified', 'Non précisée'); add('disc.trend_improving', 'Improving', 'En progrès'); add('disc.trend_stable', 'Stable', 'Stable'); add('disc.trend_concerning', 'Concerning', 'Préoccupante');
add('disc.linked_incident', 'About incident', 'À propos de l’incident'); add('disc.no_link', 'No specific incident', 'Aucun incident précis');
add('disc.n_incidents', '{n} incident(s)', '{n} incident(s)'); add('disc.n_serious', '{n} serious', '{n} grave(s)');

// ---- Discipline module (phase 3: council, decisions, sanctions) ----
add('disc.tab_council', 'Disciplinary Council', 'Conseil de discipline'); add('disc.tab_decisions', 'Decisions', 'Décisions'); add('disc.tab_sanctions', 'Sanctions', 'Sanctions');
add('disc.new_meeting', 'Schedule a meeting', 'Programmer une réunion'); add('disc.edit_meeting', 'Edit meeting', 'Modifier la réunion'); add('disc.meeting_title', 'Meeting title', 'Titre de la réunion'); add('disc.location', 'Location', 'Lieu');
add('disc.no_meetings', 'No council meetings yet.', 'Aucune réunion du conseil pour le moment.'); add('disc.n_members', '{n} member(s)', '{n} membre(s)'); add('disc.n_cases', '{n} case(s)', '{n} dossier(s)');
add('disc.meeting_scheduled', 'Scheduled', 'Programmée'); add('disc.meeting_held', 'Held', 'Tenue'); add('disc.meeting_cancelled', 'Cancelled', 'Annulée');
add('disc.members', 'Council members', 'Membres du conseil'); add('disc.no_members', 'No members registered.', 'Aucun membre enregistré.'); add('disc.no_members_available', 'No staff member has the “council member” permission yet. Grant it in Who can do what.', 'Aucun membre du personnel n’a encore le droit « membre du conseil ». Accordez-le dans « Qui peut faire quoi ».');
add('disc.role_member', 'Member', 'Membre'); add('disc.role_chair', 'Chair', 'Président(e)'); add('disc.role_secretary', 'Secretary', 'Secrétaire');
add('disc.cases', 'Cases on the agenda', 'Dossiers à l’ordre du jour'); add('disc.add_case', 'Add a case', 'Ajouter un dossier'); add('disc.no_cases', 'No cases yet.', 'Aucun dossier pour le moment.'); add('disc.remove_case', 'Remove this case from the agenda?', 'Retirer ce dossier de l’ordre du jour ?');
add('disc.council_confidential', 'Council discussions are strictly confidential. Only the administrator and the members assigned to this meeting can read them.', 'Les débats du conseil sont strictement confidentiels. Seuls l’administrateur et les membres affectés à cette réunion peuvent les lire.');
add('disc.no_decision', 'No decision yet', 'Pas encore de décision'); add('disc.facts', 'Incidents before the council', 'Incidents soumis au conseil');
add('disc.record', 'Confidential council record', 'Compte rendu confidentiel du conseil'); add('disc.record_confidential', 'This text is never shown on report cards, to parents, teachers or students, and never leaves the council.', 'Ce texte n’apparaît jamais sur les bulletins ni auprès des parents, des enseignants ou des élèves, et ne sort jamais du conseil.');
add('disc.record_hidden', 'The council’s discussion and findings are confidential and are not shown to you.', 'Les débats et conclusions du conseil sont confidentiels et ne vous sont pas affichés.');
add('disc.discussion', 'Discussion', 'Débats'); add('disc.findings', 'Findings', 'Constatations'); add('disc.locked_decision', 'The decision was approved, so this record is now locked.', 'La décision a été approuvée : ce compte rendu est maintenant verrouillé.');
add('disc.decision', 'Council decision', 'Décision du conseil'); add('disc.decision_text', 'Decision', 'Décision'); add('disc.decided_on', 'Date of decision', 'Date de la décision'); add('disc.approver', 'Authorised to approve', 'Autorisé à approuver');
add('disc.approver_hint', 'The decision is only official once this person approves it.', 'La décision n’est officielle qu’après approbation par cette personne.'); add('disc.follow_up', 'Follow-up actions', 'Actions de suivi');
add('disc.approved_by', 'Approved by {name} on {date}.', 'Approuvée par {name} le {date}.'); add('disc.rejected_reason', 'Not approved', 'Non approuvée');
add('disc.dec_draft', 'Awaiting approval', 'En attente d’approbation'); add('disc.dec_approved', 'Approved', 'Approuvée'); add('disc.dec_rejected', 'Not approved', 'Non approuvée');
add('disc.council_decisions', 'Council decisions', 'Décisions du conseil'); add('disc.no_decisions', 'No decisions.', 'Aucune décision.'); add('disc.approve', 'Approve', 'Approuver'); add('disc.reject', 'Do not approve', 'Ne pas approuver');
add('disc.approve_decision', 'Approve this decision', 'Approuver cette décision'); add('disc.reject_decision', 'Do not approve this decision (reason)', 'Ne pas approuver cette décision (motif)'); add('disc.comment', 'Comment', 'Commentaire');
add('disc.sanctions', 'Sanctions', 'Sanctions'); add('disc.sanction', 'Sanction', 'Sanction'); add('disc.no_sanctions', 'No sanctions.', 'Aucune sanction.'); add('disc.propose_sanction', 'Propose a sanction', 'Proposer une sanction'); add('disc.propose', 'Propose', 'Proposer');
add('disc.sanction_proposed', 'Sanction proposed. It is not in force until it is approved.', 'Sanction proposée. Elle n’est pas en vigueur tant qu’elle n’est pas approuvée.');
add('disc.sanction_needs_approval', 'A sanction is only a proposal until an authorised person approves it.', 'Une sanction n’est qu’une proposition tant qu’une personne autorisée ne l’a pas approuvée.');
add('disc.reason', 'Reason', 'Motif'); add('disc.duration_days', 'Duration (days)', 'Durée (jours)'); add('disc.n_days', '{n} day(s)', '{n} jour(s)'); add('disc.linked_decision', 'Council decision', 'Décision du conseil');
add('disc.proposed_by', 'Proposed by', 'Proposée par'); add('disc.authorized_by', 'Authorised by', 'Autorisée par');
add('disc.san_proposed', 'Awaiting approval', 'En attente d’approbation'); add('disc.san_approved', 'In force', 'En vigueur'); add('disc.san_rejected', 'Not approved', 'Non approuvée'); add('disc.san_withdrawn', 'Withdrawn', 'Retirée');
add('disc.notif_not_notified', 'Parent not notified', 'Parent non informé'); add('disc.notif_notified', 'Parent notified', 'Parent informé');
add('disc.approve_sanction', 'Approve this sanction', 'Approuver cette sanction'); add('disc.reject_sanction', 'Do not approve this sanction (reason)', 'Ne pas approuver cette sanction (motif)'); add('disc.withdraw', 'Withdraw', 'Retirer'); add('disc.withdraw_sanction', 'Withdraw this sanction (reason)', 'Retirer cette sanction (motif)');

// ---- Discipline module (phase 4: parent convocations) ----
add('disc.tab_convocations', 'Convocations', 'Convocations'); add('disc.convocations', 'Parent convocations', 'Convocations des parents'); add('disc.new_convocation', 'New convocation', 'Nouvelle convocation');
add('disc.no_convocations', 'No convocations yet.', 'Aucune convocation pour le moment.'); add('disc.cv_date', 'Meeting date', 'Date de la rencontre'); add('disc.cv_yes', 'Yes', 'Oui'); add('disc.cv_no', 'No', 'Non');
add('disc.guardian', 'Parent / guardian on file', 'Parent / tuteur enregistré'); add('disc.other_recipient', 'Someone else (type the name)', 'Autre personne (saisir le nom)'); add('disc.recipient_name', 'Recipient name', 'Nom du destinataire');
add('disc.reason_for_parent', 'Reason shown to the parent', 'Motif communiqué au parent'); add('disc.instructions', 'Instructions (optional)', 'Consignes (facultatif)');
add('disc.cv_reason_note', 'The letter shows only the reason you write here. Confidential council notes are never copied into it.', 'La lettre n’affiche que le motif écrit ici. Les notes confidentielles du conseil n’y sont jamais copiées.');
add('disc.cv_draft', 'Draft', 'Brouillon'); add('disc.cv_approved', 'Approved', 'Approuvée'); add('disc.cv_rejected', 'Not approved', 'Non approuvée'); add('disc.cv_postponed', 'Postponed', 'Reportée'); add('disc.cv_cancelled', 'Cancelled', 'Annulée'); add('disc.cv_completed', 'Completed', 'Terminée');
add('disc.cv_letter', 'Official letter (A4)', 'Lettre officielle (A4)'); add('disc.cv_letter_note', 'Download, print and sign. Then record below how it reached the parent. JAO does not send it and does not claim it was delivered.', 'Téléchargez, imprimez et signez. Enregistrez ensuite ci-dessous comment elle a été remise au parent. JAO ne l’envoie pas et ne prétend pas qu’elle a été reçue.');
add('disc.cv_approve', 'Approve this convocation', 'Approuver cette convocation'); add('disc.cv_reject', 'Do not approve (reason)', 'Ne pas approuver (motif)'); add('disc.cv_postpone', 'Postpone', 'Reporter'); add('disc.cv_complete', 'Mark as completed', 'Marquer comme terminée'); add('disc.cv_cancel', 'Cancel convocation (reason)', 'Annuler la convocation (motif)');
add('disc.cv_record_handover', 'Record hand-over', 'Enregistrer la remise'); add('disc.cv_method', 'How was it given?', 'Comment a-t-elle été remise ?'); add('disc.cv_hand_delivered', 'Handed to the parent', 'Remise en main propre'); add('disc.cv_printed', 'Printed', 'Imprimée'); add('disc.cv_downloaded', 'Downloaded', 'Téléchargée');
add('disc.cv_handover_note', 'This is a record made by staff. It is not an automatic delivery report.', 'Ceci est une note saisie par le personnel. Ce n’est pas un rapport de livraison automatique.'); add('disc.cv_handed', 'Hand-over recorded', 'Remise enregistrée');
add('disc.cv_record_response', 'Record parent response / outcome', 'Enregistrer la réponse du parent / l’issue'); add('disc.cv_parent_response', 'Parent response', 'Réponse du parent'); add('disc.cv_resp_none', 'No response yet', 'Pas encore de réponse'); add('disc.cv_resp_attending', 'Will attend', 'Sera présent'); add('disc.cv_resp_unable', 'Cannot attend', 'Ne peut pas venir');
add('disc.cv_attended', 'Attended', 'Présent à la rencontre'); add('disc.cv_outcome', 'Outcome of the meeting', 'Issue de la rencontre'); add('disc.cv_history', 'History', 'Historique');
add('disc.cv_ev_created', 'Created', 'Créée'); add('disc.cv_ev_edited', 'Edited', 'Modifiée'); add('disc.cv_ev_approved', 'Approved', 'Approuvée'); add('disc.cv_ev_rejected', 'Not approved', 'Non approuvée'); add('disc.cv_ev_postponed', 'Postponed', 'Reportée'); add('disc.cv_ev_cancelled', 'Cancelled', 'Annulée'); add('disc.cv_ev_completed', 'Completed', 'Terminée');
add('disc.cv_ev_response_recorded', 'Response / outcome recorded', 'Réponse / issue enregistrée'); add('disc.cv_ev_handover_printed', 'Hand-over: printed', 'Remise : imprimée'); add('disc.cv_ev_handover_hand_delivered', 'Hand-over: handed to the parent', 'Remise : en main propre'); add('disc.cv_ev_handover_downloaded', 'Hand-over: downloaded', 'Remise : téléchargée');
add('err.invalid_time', 'Enter a valid time (HH:MM).', 'Saisissez une heure valide (HH:MM).'); add('err.recipient_required', 'Choose or type who the letter is for.', 'Choisissez ou saisissez le destinataire de la lettre.'); add('err.location_required', 'Enter the place of the meeting.', 'Saisissez le lieu de la rencontre.');
add('err.invalid_guardian', 'That parent is not linked to this student.', 'Ce parent n’est pas lié à cet élève.'); add('err.invalid_method', 'Choose how it was handed over.', 'Choisissez comment elle a été remise.'); add('err.invalid_response', 'Invalid response.', 'Réponse invalide.'); add('err.invalid_case', 'Invalid council case.', 'Dossier du conseil invalide.');

// ---- Phase 5: notifications and message preparation ----
add('nav.my-convocations', 'Convocations', 'Convocations'); add('disc.my_cv_sub', 'Letters from the school about your children.', 'Courriers de l’école concernant vos enfants.');
add('notify.convocation_issued', 'New convocation for {student}: {date} at {time}', 'Nouvelle convocation pour {student} : {date} à {time}');
add('notify.convocation_postponed', 'Convocation for {student} postponed to {date} at {time}', 'Convocation de {student} reportée au {date} à {time}');
add('notify.convocation_cancelled', 'Convocation for {student} cancelled', 'Convocation de {student} annulée');
add('disc.cv_ch_whatsapp', 'WhatsApp', 'WhatsApp'); add('disc.cv_ch_email', 'Email', 'E-mail'); add('disc.cv_ch_sms', 'SMS', 'SMS'); add('disc.cv_status_prepared', 'prepared', 'préparé');
add('disc.cv_prepared', 'Message prepared in your own app. Check it and press send there.', 'Message préparé dans votre application. Vérifiez-le et envoyez-le depuis celle-ci.');
add('disc.cv_prepare_note', 'These buttons open a ready-made short message in WhatsApp, your email or SMS app, using the parent’s saved contact. JAO does not send it and cannot tell whether it was delivered. The message never contains the reason.', 'Ces boutons ouvrent un court message prêt à envoyer dans WhatsApp, votre messagerie ou vos SMS, avec le contact enregistré du parent. JAO ne l’envoie pas et ne peut pas savoir s’il a été reçu. Le message ne contient jamais le motif.');
add('disc.cv_ev_prepared_whatsapp', 'WhatsApp message prepared', 'Message WhatsApp préparé'); add('disc.cv_ev_prepared_email', 'Email prepared', 'E-mail préparé'); add('disc.cv_ev_prepared_sms', 'SMS prepared', 'SMS préparé');
add('err.invalid_channel', 'Choose WhatsApp, email or SMS.', 'Choisissez WhatsApp, e-mail ou SMS.'); add('err.no_contact', 'No usable phone number or email is saved for this parent.', 'Aucun numéro ou e-mail utilisable n’est enregistré pour ce parent.');

// ---- Phase 6: report card ----
add('reports.discipline', 'Conduct and discipline', 'Conduite et discipline'); add('reports.conduct_n', '{n} confirmed incident(s) this year, of which {s} serious.', '{n} incident(s) confirmé(s) cette année, dont {s} grave(s).');
add('reports.conduct_none', 'No confirmed incident this year.', 'Aucun incident confirmé cette année.'); add('reports.no_decisions', 'No approved council decision this year.', 'Aucune décision du conseil approuvée cette année.');
